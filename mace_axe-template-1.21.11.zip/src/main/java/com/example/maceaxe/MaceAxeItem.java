package com.example.maceaxe;

import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.Items;
import net.minecraft.item.MaceItem;
import net.minecraft.util.ActionResult;

/**
 * Extends the vanilla MaceItem, so the smash attack (fall-distance bonus damage,
 * ground slam knockback, Density/Breach/Wind Burst) all work exactly like a real mace.
 * Axe features come from Item.Settings#axe (see MaceAxeMod) plus the log-stripping below.
 */
public class MaceAxeItem extends MaceItem {
    public MaceAxeItem(Item.Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        // Borrow the vanilla axe's strip / scrape / wax-off logic.
        ActionResult result = Items.NETHERITE_AXE.useOnBlock(context);
        return result != ActionResult.PASS ? result : super.useOnBlock(context);
    }
}
