package com.example.maceaxe;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ToolMaterial;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;

public class MaceAxeMod implements ModInitializer {
    public static final String MOD_ID = "maceaxe";

    public static Item MACE_AXE;

    @Override
    public void onInitialize() {
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(MOD_ID, "mace_axe"));

        // .axe(...) gives axe behaviour: axe-mineable tool rules, attack damage/speed
        // attributes, durability from the material, and shield-disabling.
        // Tweak damage (3rd arg 1) and attack speed (3rd arg 2) to balance it.
        Item.Settings settings = new Item.Settings()
                .registryKey(key)
                .rarity(Rarity.EPIC)
                .axe(ToolMaterial.NETHERITE, 7.0F, -3.3F);

        MACE_AXE = Registry.register(Registries.ITEM, key, new MaceAxeItem(settings));

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(e -> e.add(MACE_AXE));
    }
}
